# Plan: 001 — Mi primera feature

## Enfoque técnico

## Archivos a modificar

## Pasos
